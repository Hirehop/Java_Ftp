package xyz.kuoa.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import xyz.kuoa.dao.FtpUserDao;
import xyz.kuoa.domain.FtpUser;
import xyz.kuoa.utils.DBUtils;

public class FtpUserDaoImpl implements FtpUserDao{

	@Override
	public FtpUser getUser(FtpUser user) throws Exception {
		//��ȡ����
		String username = user.getUsername();
		String password = user.getPassword();
		
		//��������
		ResultSet rs = null;
		FtpUser u = null;
		Connection conn = null;
		PreparedStatement ps = null;
		
		try {
			conn = DBUtils.getConnection();
			ps = conn.prepareStatement("SELECT * FROM ftp WHERE username=? AND password=?");
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			
			if(rs.next()){
				u = new FtpUser();
				u.setUsername(rs.getString(1));
				u.setPassword(rs.getString(2));
				u.setCapacity(rs.getString(3));
				u.setWorkingDirectory(rs.getString(4));
			}
		} catch (Exception e) {
			//e.printStackTrace();
			throw new RuntimeException("��¼ʧ��");
		} finally{
			DBUtils.closeAll(rs, ps, conn);
		}
		
		return u;
	}
}
