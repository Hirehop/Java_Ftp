package xyz.kuoa.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import xyz.kuoa.dao.FtpUserDao;
import xyz.kuoa.dao.impl.FtpUserDaoImpl;
import xyz.kuoa.domain.FtpUser;
import xyz.kuoa.service.FtpUserService;

public class FtpUserServiceImpl implements FtpUserService {

	@Override
	public FtpUser login(FtpUser user) {
		FtpUser u = null;

		FtpUserDao dao = new FtpUserDaoImpl();
		try {
			u = dao.getUser(user);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return u;
	}

	/**
	 * Environment:Windows
	 * success return: String result
	 * fail return:    null
	 */
	@Override
	public String runCommand(String command) {
		// String[] cmd = new String[]{"/bin/bash","-c","ls -l"};
		String[] cmd = new String[3];
		cmd[0] = "cmd";
		cmd[1] = "/c";
		cmd[2] = command;
		BufferedReader bufferedReader = null;
		BufferedReader errorBufferedReader = null;
		try {
			Process ps = Runtime.getRuntime().exec(cmd);
			bufferedReader = new BufferedReader(new InputStreamReader(ps.getInputStream(), "GBK"));
			errorBufferedReader = new BufferedReader(new InputStreamReader(ps.getErrorStream(), "GBK"));
			StringBuffer stringBuffer = new StringBuffer();
			StringBuffer errorStringBuffer = new StringBuffer();
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuffer.append(line).append("\n");
			}
			while ((line = errorBufferedReader.readLine()) != null) {
				errorStringBuffer.append(line).append("\n");
			}
			String result = stringBuffer.toString();
			String errorResult = stringBuffer.toString();

			if ("".equals(result)) {
				System.out.println(errorResult);
			}else{
				return result;
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}
}
