package xyz.kuoa.service;

import xyz.kuoa.domain.FtpUser;

public interface FtpUserService {
	/**
	 * Login
	 * @param the FtpUser only have username+password
	 * @return full FtpUser had all attributes
	 */
	FtpUser login(FtpUser user);
	
	/**
	 * execute command
	 * @param command
	 * @return Right:result String; Error:null object
	 */
	String runCommand(String command);
	
}
