package xyz.kuoa.utils;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

/**
 * ���ݿ����������
 * @author X
 *
 */
public class DBUtils {
	private static String driverClass;
	private static String url;
	private static String username;
	private static String password;
 
	static {
		String proFilePath = System.getProperty("user.dir") + "\\config\\dbinfo.properties";
		ResourceBundle rb = null;
		try {
			BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(proFilePath));
			rb = new PropertyResourceBundle(bufferedInputStream);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		driverClass = rb.getString("driverClass");
		url = rb.getString("url");
		username = rb.getString("username");
		password = rb.getString("password");
		try {
			Class.forName(driverClass);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
 
	public static Connection getConnection() throws Exception {
		return DriverManager.getConnection(url, username, password);
	}
	
	public static void closeAll(ResultSet rs,Statement stat,Connection conn){
		if(rs!=null){
			try {
				rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			rs = null;
		}
		if(stat!=null){
			try {
				stat.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			stat = null;
		}
		if(conn!=null){
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			conn = null;
		}
	}
}