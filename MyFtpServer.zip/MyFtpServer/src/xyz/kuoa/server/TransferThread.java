package xyz.kuoa.server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

import xyz.kuoa.service.FtpUserService;
import xyz.kuoa.service.impl.FtpUserServiceImpl;

public class TransferThread implements Runnable {
	// TransferToken: End Of Transfer
	private static int EOT = 4;
	// TransferToken: file not found
	private static int ENQ = 5;
	//The server local Path
	private static String localPath = "C:\\Users\\X\\Desktop\\JAVA\\WorkSpace_2\\MyFtp\\";
	
	private Socket clientSocket;
	private String username;
	
	public TransferThread() {}
	public TransferThread(Socket clientSocket) {
		this.clientSocket = clientSocket;
	}
	

	@Override
	public void run() {
		FtpUserService service = new FtpUserServiceImpl();
		
		BufferedReader br;
		BufferedWriter bw;
		try {
			br = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			bw = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
			char[] buf = new char[1];
			StringBuffer sb = new StringBuffer();
			while((br.read(buf, 0, buf.length))!=-1){
				String str = new String(buf);
				if(str.getBytes()[0]==EOT){
					break;
				}
				sb.append(str);
			}
			username = sb.toString();
			// create current user's working directory in server 
			service.runCommand("mkdir "+localPath+username);
			
			// get command from client and parse/execute it
			while(true){
				char[] buf1 = new char[1];
				StringBuffer sb1 = new StringBuffer();
				while((br.read(buf1, 0, buf1.length))!=-1){
					String str1 = new String(buf1);
					if(str1.getBytes()[0]==EOT){
						break;
					}
					sb1.append(str1);
				}
				
				if("ls".equals(sb1.toString().substring(0,2))){
					// unpack date from client
					// date fromat: 'command#current working directory'
					String[] temp = sb1.toString().split("#");
					String lsCommand = "dir "+localPath+temp[1];
					String res = service.runCommand(lsCommand);
					// response to client
					if(res!=null){
						bw.write(res);
						bw.write(EOT);
						bw.flush();
					}else{
						System.out.println("cmd error");
					}
				}
				
				// deal with two commands
				// get + put
				if("put".equals(sb1.toString().substring(0,3))){
					String[] putSplit = sb1.toString().split("#");
					
					BufferedWriter upFileBw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(localPath+username+"\\"+putSplit[1])));
					
					char[] buf2 = new char[1];
					while((br.read(buf2, 0, buf2.length))!=-1){
						String str2 = new String(buf2);
						if(str2.getBytes()[0]==EOT){
							break;
						}
						upFileBw.write(str2.toString());
					}
					upFileBw.close();
					// return result status to client
					bw.write("[ upload success! ]");
					bw.write(EOT);
					bw.flush();
					continue;
				}
				if("get".equals(sb1.toString().substring(0,3))){
					String[] getSplit = sb1.toString().split("#");
					
					// receive the filename from client and judge the existence of it
					String localFileFullpath = localPath+username+"\\"+getSplit[1].toString();
					
					System.out.println(localFileFullpath);
					
					File clientDownloadFile = new File(localFileFullpath);
					if(!clientDownloadFile.exists()){
						// return error message
						// ENQ = 5: NOT FOUND FILE IN SERVER
						bw.write(ENQ);
						bw.flush();
						continue;
					}else{
						
						System.out.println("Transfering");
						
						// return right message
						// transfer file date
						BufferedReader downFileBr;
						try {
							downFileBr = new BufferedReader(new InputStreamReader(
									new FileInputStream(localFileFullpath), "GBK"));
							char[] chs = new char[1024];
							int len;
							while ((len = downFileBr.read(chs)) != -1) {
								bw.write(chs, 0, len);
								bw.flush();
							}
							bw.write(EOT);
							bw.flush();
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						}
					}
					continue;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}			
		
	}

}
