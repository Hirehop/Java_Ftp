package xyz.kuoa.server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

import xyz.kuoa.domain.FtpUser;
import xyz.kuoa.service.FtpUserService;
import xyz.kuoa.service.impl.FtpUserServiceImpl;

/**
 * Control Thread to validate username and password
 * @author X
 *
 */
public class ControlThread implements Runnable {
	private static final int EOT = 4;

	private Socket clientSocket;

	public ControlThread() {}

	public ControlThread(Socket sc) {
		this.clientSocket = sc;
	}

	@Override
	public void run() {
		FtpUserService service = new FtpUserServiceImpl();
		FtpUser user = new FtpUser();

		try {
			// receive data
			BufferedReader br = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			char[] buf1 = new char[1];
			StringBuffer sb1 = new StringBuffer();
			while ((br.read(buf1, 0, buf1.length)) != -1) {
				String str1 = new String(buf1);
				if (str1.getBytes()[0] == EOT) {
					break;
				}
				sb1.append(str1);
			}
			String line = sb1.toString();
			String[] loginSplitRes = line.split("#");
			String username = loginSplitRes[0];
			String password = loginSplitRes[1];
			user.setUsername(username);
			user.setPassword(password);

			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream(), "GBK"));
 			// cite the login method in serverLayer
			// success return full FtpUser
			// fail return null
			user = service.login(user);
			if (user != null) {

				// pack user's date to String 
				// split by '#'
				StringBuffer buffer = new StringBuffer();
				buffer.append(user.getUsername());
				buffer.append("#");
				buffer.append(user.getPassword());
				buffer.append("#");
				buffer.append(user.getCapacity());
				buffer.append("#");
				buffer.append(user.getWorkingDirectory());

				// response to client
				// success return real String
				// fail return String null
				bw.write(buffer.toString());
				bw.newLine();
				bw.flush();
			} else {
				bw.write("null");
				bw.newLine();
				bw.flush();
			}
			// release
			bw.close();
			clientSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
