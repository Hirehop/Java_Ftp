package xyz.kuoa.server;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

public class MyServer {

	public static void main(String[] args) {
		String proFilePath = System.getProperty("user.dir") + "\\config\\port.properties";
		ResourceBundle rb = null;
		try {
			BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(proFilePath));
			rb = new PropertyResourceBundle(bufferedInputStream);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		// Start two ports
		// Control Port
		// Transfer Port
		int ctlPort = Integer.valueOf(rb.getString("ctlport"));
		int traPort = Integer.valueOf(rb.getString("traport"));

		ServerSocket controlSocket = null;
		ServerSocket transferSocket = null;
		try {
			controlSocket = new ServerSocket(ctlPort);
			transferSocket = new ServerSocket(traPort);

			// Start Accept
			while (true) {
				Socket controlSc = controlSocket.accept();
				Socket transferSc = transferSocket.accept();
				new Thread(new ControlThread(controlSc)).start();
				new Thread(new TransferThread(transferSc)).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (transferSocket != null) {
					transferSocket.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
}
