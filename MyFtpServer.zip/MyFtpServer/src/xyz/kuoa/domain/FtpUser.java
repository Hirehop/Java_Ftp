package xyz.kuoa.domain;

public class FtpUser {
	private String username;
	private String password;
	private String capacity;
	private String workingDirectory;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public String getWorkingDirectory() {
		return workingDirectory;
	}

	public void setWorkingDirectory(String workingDirectory) {
		this.workingDirectory = workingDirectory;
	}

	@Override
	public String toString() {
		return "FtpUser [username=" + username + ", password=" + password + ", capacity=" + capacity
				+ ", workingDirectory=" + workingDirectory + "]";
	}
}
