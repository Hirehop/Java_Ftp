package xyz.kuoa.service;

import java.net.Socket;

/**
 * �ͻ��˷���ӿ�
 * @author X
 *
 */
public interface FtpUserService {
	
	/**
	 * initialization the ftp client
	 * @return Socket[0]:control Socket[1]:transfer
	 */
	Socket[] init();
	
	
	/**
	 * ִ��cmd/shell����
	 * @param command
	 * @return
	 */
	String runCommand(String command);
	
}
