package xyz.kuoa.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

import xyz.kuoa.service.FtpUserService;

public class FtpUserServiceImpl implements FtpUserService {
	
	private static final String IP = "192.168.0.105";
	
	@Override
	public Socket[] init(){
		// create the local working directory
		this.runCommand("mkdir D:\\MyFtp_v1.0");
		Socket[] twoSockets = new Socket[2];
		try {
			twoSockets[0] = new Socket(IP, 10020);
			twoSockets[1] = new Socket(IP, 10021);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return twoSockets;
	}

	/**
	 * Environment:Windows
	 * success return: String result
	 * fail return:    null
	 */
	@Override
	public String runCommand(String command) {
		// String[] cmd = new String[]{"/bin/bash","-c","ls -l"};
		String[] cmd = new String[3];
		cmd[0] = "cmd";
		cmd[1] = "/c";
		cmd[2] = command;
		BufferedReader bufferedReader = null;
		BufferedReader errorBufferedReader = null;
		try {
			Process ps = Runtime.getRuntime().exec(cmd);
			bufferedReader = new BufferedReader(new InputStreamReader(ps.getInputStream(), "GBK"));
			errorBufferedReader = new BufferedReader(new InputStreamReader(ps.getErrorStream(), "GBK"));
			StringBuffer stringBuffer = new StringBuffer();
			StringBuffer errorStringBuffer = new StringBuffer();
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuffer.append(line).append("\n");
			}
			while ((line = errorBufferedReader.readLine()) != null) {
				errorStringBuffer.append(line).append("\n");
			}
			String result = stringBuffer.toString();
			String errorResult = stringBuffer.toString();

			if ("".equals(result)) {
				System.out.println(errorResult);
			}else{
				return result;
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}



}
