package xyz.kuoa.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.Scanner;

import xyz.kuoa.domain.FtpUser;
import xyz.kuoa.service.FtpUserService;
import xyz.kuoa.service.impl.FtpUserServiceImpl;

public class MyClient {
	private static final int EOT = 4;
	private static final int ENQ = 5;

	static FtpUserService service = new FtpUserServiceImpl();
	static Socket[] twoSockets = null;
	static Scanner sc = new Scanner(System.in);
	static BufferedReader br;
	static BufferedReader br1;
	static BufferedWriter bw;
	static BufferedWriter bw1;
	static BufferedReader localFileBufferedReader;

	public static void main(String[] args) throws Exception {
		FtpUser user = new FtpUser();
		// show welcome info in top of the client console
		ClientWelcome.displayWelcome();
		String loginInfo = loginBefore();
		if (loginInfo == null)
			return;
		twoSockets = service.init();

		String controlResponse = "null";
		try {
			controlResponse = validateLogin(loginInfo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// check the response of server(the value of controlResponse)
		if ("null".equals(controlResponse)) {
			System.out.println("login error");
		} else {
			String[] serverReturnSplit = controlResponse.split("#");
			user.setUsername(serverReturnSplit[0]);
			user.setPassword(serverReturnSplit[1]);
			user.setCapacity(serverReturnSplit[2]);
			user.setWorkingDirectory(serverReturnSplit[3]);

			// create current user's working directory in server
			br1 = new BufferedReader(new InputStreamReader(twoSockets[1].getInputStream(), "GBK"));
			bw1 = new BufferedWriter(new OutputStreamWriter(twoSockets[1].getOutputStream()));
			bw1.write(user.getWorkingDirectory());
			bw1.write(EOT);
			bw1.flush();

			// login success and show a new view with different functions
			loginAfter(user);
		}
	}

	/**
	 * check login from control port
	 * 
	 * @param loginInfo
	 * @return
	 * @throws UnsupportedEncodingException
	 * @throws IOException
	 */
	private static String validateLogin(String loginInfo) throws UnsupportedEncodingException, IOException {
		// get inputstream and outputStream in controlPort to validate the
		// username and password
		br = new BufferedReader(new InputStreamReader(twoSockets[0].getInputStream(), "GBK"));
		bw = new BufferedWriter(new OutputStreamWriter(twoSockets[0].getOutputStream()));
		// send String 'loginInfo' which is the pack of 'username#password'
		// end of EOT
		bw.write(loginInfo);
		bw.write(EOT);
		bw.flush();
		String controlResponse = null;
		controlResponse = br.readLine();
		return controlResponse;
	}

	/**
	 * local login view, just show and compress username and password
	 * 
	 * @return String of 'username#password'
	 */
	public static String consoleLogin() {
		StringBuffer buffer = new StringBuffer();
		System.out.println("-----------Login-----------");
		System.out.print("Username��");
		buffer.append(sc.nextLine().trim());
		buffer.append("#");
		System.out.print("Password��");
		buffer.append(sc.nextLine().trim());
		return buffer.toString();
	}

	/**
	 * client view before login
	 * 
	 * @param user
	 * @param service
	 */
	public static String loginBefore() {
		String res = null;
		String command = new String();
		try {
			while (true) {
				System.out.print("ftp >");
				if (sc.hasNextLine()) {
					command = sc.nextLine().trim();
					if (command.equals("bye")) {
						System.out.println("----Bye~----");
						return null;
					} else if (command.equals("login")) {
						res = consoleLogin();
						return res;
					} else if (command.equals("help")) {
						System.out.println("Supported Command List��");
						System.out.println("login");
						System.out.println("bye");
					} else {
						System.out.println("Command not support, use 'help' find more");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	/**
	 * client view after login
	 * 
	 * @param user
	 * @param service
	 */
	public static void loginAfter(FtpUser user) {
		String command = new String();
		try {
			while (true) {
				System.out.print("ftp [" + user.getUsername() + "]>");
				if (true) {
					command = sc.nextLine().trim();

					if (command.length() == 1) {
						System.out.println("Command not support, use 'help' find more");
					}
					if (command.length() == 2) {
						if (command.equals("ls")) {
							runLS(user);
							continue;
						}else {
							System.out.println("Command not support, use 'help' find more");
							continue;
						}
						
					}
					if (command.length() == 3) {
						if (command.equals("bye")) {
							System.out.println("----Bye~----");
							break;
						} else {
							System.out.println("Command not support, use 'help' find more");
							continue;
						}
					}
					if (command.length() > 3) {
						if (command.equals("help")) {
							runHELP();
							continue;
						}
						if (command.substring(0, 4).equals("get ")) {
							runGET(command);
							continue;
						}
						if (command.substring(0, 4).equals("put ")) {
							runPUT(command);
							continue;
						} else {
							System.out.println("Command not support, use 'help' find more");
							continue;
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void runHELP() {
		System.out.println("Supported Command List��");
		System.out.println("bye");
		System.out.println("ls");
		System.out.println("cd");
		System.out.println("get [filename]");
		System.out.println("put [filename]");
	}

	private static void runPUT(String command) throws UnsupportedEncodingException, FileNotFoundException, IOException {
		// Local working path��D:\\MyFtp_v1.0
		String[] putSplit = command.split(" ");
		if (putSplit.length == 1 || putSplit.length > 2) {
			System.out.println("Format error��[ put filename ]");
		} else {
			String upFilename = putSplit[1];
			localFileBufferedReader = new BufferedReader(new InputStreamReader(
					new FileInputStream("D:\\MyFtp_v1.0\\" + upFilename), "GBK"));

			// send [put token] to server
			bw1.write("put#" + upFilename);
			bw1.write(EOT);
			bw1.flush();

			char[] chs = new char[1024];
			int len;
			while ((len = localFileBufferedReader.read(chs)) != -1) {
				bw1.write(chs, 0, len);
				bw1.flush();
			}
			bw1.write(EOT);
			bw1.flush();

			char[] buf1 = new char[1];
			StringBuffer sb1 = new StringBuffer();
			while ((br1.read(buf1, 0, buf1.length)) != -1) {
				String str1 = new String(buf1);
				if (str1.getBytes()[0] == EOT) {
					break;
				}
				sb1.append(str1);
			}
			System.out.println(sb1.toString());
			localFileBufferedReader.close();
		}
	}

	private static void runGET(String command) throws FileNotFoundException, IOException {
		BufferedWriter toClientBw = null;
		// Local working path��D:\\MyFtp_v1.0
		String[] getSplit = command.split(" ");
		if (getSplit.length == 1 || getSplit.length > 2) {
			System.out.println("Format error��[ get filename ]");
		} else {
			// create local file paeparing to receive date
			// from server
			// if server response is ENQ, delete this empty
			// file
			String getFilename = getSplit[1];
			File filefromServer = new File("D:\\MyFtp_v1.0\\" + getFilename);
			toClientBw = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream("D:\\MyFtp_v1.0\\" + getFilename)));
			// send [get token] to server
			bw1.write("get#" + getFilename);
			bw1.write(EOT);
			bw1.flush();
			
			System.out.println("send OK");
			
			// receive esponse from server
			// ENQ or others
			char[] buf1 = new char[1];
			while ((br1.read(buf1, 0, buf1.length)) != -1) {
				String str1 = new String(buf1);
				if (str1.getBytes()[0] == ENQ) {
					System.out.println("[ file not exists on Server! ]");
					// first close the outputstream using
					// this temporary file
					// then delete this empty file
					toClientBw.close();
					filefromServer.delete();
					filefromServer = null;
					break;
				}
				if (str1.getBytes()[0] == EOT) {
					break;
				}
				// write date to local file
				toClientBw.write(str1);
				toClientBw.flush();
			}
			if (filefromServer != null) {
				System.out.println("download success");
			}
			toClientBw.close();
		}
	}

	private static void runLS(FtpUser user) throws IOException {
		// execute ls command
		// send date to server: 'ls#workdingDirectory'
		bw1.write("ls#" + user.getWorkingDirectory());
		bw1.write(EOT);
		bw1.flush();
		// get response from server
		char[] buf1 = new char[1];
		StringBuffer sb1 = new StringBuffer();
		while ((br1.read(buf1, 0, buf1.length)) != -1) {
			String str1 = new String(buf1);
			if (str1.getBytes()[0] == EOT) {
				break;
			}
			sb1.append(str1);
		}
		System.out.println(sb1.toString());
	}
}
