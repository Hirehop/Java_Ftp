package xyz.kuoa.client;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

public class ClientWelcome {

	/**
	 * ��info.properties�����ļ��ж�ȡKFTP�汾��Ϣ����ʽ��
	 * 
	 * @throws Exception
	 */
	List<String> formatConf() throws Exception {
		String proFilePath = System.getProperty("user.dir") + "\\config\\info.properties";
		ResourceBundle rb = null;
		try {
			BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(proFilePath));
			rb = new PropertyResourceBundle(bufferedInputStream);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		List<String> welcomeInfoList = new ArrayList<>();
		welcomeInfoList.add("---version: " + rb.getString("version") + "---");
		welcomeInfoList.add("---developer" + rb.getString("developer") + "---");
		welcomeInfoList.add("---welcome" + rb.getString("welcome") + "---");
		welcomeInfoList.add("---defaultDir" + rb.getString("defaultDir") + "---");
		return welcomeInfoList;
	}

	/**
	 * �����ӭ��Ϣ
	 * 
	 * @throws Exception
	 */
	static void displayWelcome() throws Exception {
		List<String> list = new ClientWelcome().formatConf();
		for (String item : list) {
			System.out.println(item);
		}
		System.out.println();
	}

}